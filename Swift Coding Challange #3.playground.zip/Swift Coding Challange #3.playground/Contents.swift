/*
    Create a function that takes in a string parameter for the user input, and than create a rock paper scissor shoot game.
    NOTE you may not use any AI libraries to do this. IT'S NOT IMPOSSIBLE. Good luck!
 */




































import Foundation

func rps(str:String) -> Void {
    str.lowercased()//Clears the cornercase when someone spells the correct answer with a capital letter, or writes it in all capse.
    if str == "paper" {
        var compute = ["rock", "scissors"]
        compute.shuffle()//Better safe than sorry, shuffle before you randomize to insure true randomness, and no pattern is followed.
        let randChoice = compute.randomElement()//This line of code create a variable with the random answer chosen from the compute array.
        if randChoice == "rock"{
            print("\nrock - you win!\n")
        }
        if randChoice!.lowercased() == "scissors" {
            print("\nscissors - you lose!\n")
        }
    }//END -> paper cornercase
    if str == "scissors" {
        var compute = ["rock", "paper"]
        compute.shuffle()//Better safe than sorry, shuffle before you randomize to insure true randomness, and no pattern is followed.
        let randChoice = compute.randomElement()//This line of code create a variable with the random answer chosen from the compute array.
        if randChoice == "rock"{
            print("\nrock - you lose!\n")
        }
        if randChoice! == "paper" {
            print("\npaper - you win!\n")
        }
    }//END -> scissors cornercase
    if str == "rock" {
        var compute = ["scissors", "paper"]
        compute.shuffle()//Better safe than sorry, shuffle before you randomize to insure true randomness, and no pattern is followed.
        let randChoice = compute.randomElement()//This line of code create a variable with the random answer chosen from the compute array.
        if randChoice == "scissors"{
            print("\nscissors - you win!\n")
        }
        if randChoice == "paper" {
            print("\npaper - draw!\n")
        }
    }//END -> rock cornercase
    else if str != "rock" && str != "paper" && str != "scissors" {
        print("Something went wrong please try again!")
    }/* In this case else by itself will produce a bug
     where the error appears with any solution.
     else if allows for us to have control of when to print the error.
    */
 }
rps(str: "idk")
