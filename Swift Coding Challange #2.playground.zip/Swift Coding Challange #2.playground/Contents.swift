/*
    Create a function that counts from the
beginning of a range to the end of a range in reverse, and than prints it's values.
 */

import Foundation

func revCount(from:Int, to:Int) -> Void {
    var array = [Int]()
    for i in to..<from+1 {
        array.append(i)
    }
    for j in 0..<array.count {
        print(array.reversed()[j])
    }
}
revCount(from: 120, to: 100)
