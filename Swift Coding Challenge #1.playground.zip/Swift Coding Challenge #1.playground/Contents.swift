
/*
Create a function called gender that initializes two booleans, male and female within its parameters.
 */

import UIKit

struct type{
    let Male:Bool
    let Female:Bool
}
func gender(Type:type) -> String {
    if Type.Male && Type.Female == false {
        return "Male"
    }
    if Type.Female && Type.Male == false{
        return "Female"
    }else{
        return "Error: Invalid gender"
    }
}
print(gender(Type: .init(Male: false, Female: true)))
